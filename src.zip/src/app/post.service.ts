import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http'
import {Post} from './post.model'
import {map} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class PostService {

  endPointURL:string = 'https://angular-exercise-6d5a3-default-rtdb.asia-southeast1.firebasedatabase.app/';
  postURL: string = this.endPointURL+'post.json';
  constructor(private http: HttpClient) { }

  //for posting data
  createAndPost(postData: Post) {
    this.http.post<{name: string}>(this.postURL, postData).subscribe(
      (data) => {
        console.log(data);
      }
    );
  }

  updateAndPost(putData: { id: string, title: string; content: string }) {
    const updateData = {
      [putData.id]: {title: putData.title, content: putData.content}
    };
    this.http.patch(this.postURL, updateData).subscribe((data) => {
      console.log(data);
    });
  }

  //for fetching data
  fetchPosts() {
    return this.http.get<{[key: string] : Post}>(this.postURL, {
      headers: new HttpHeaders({
        'custom-header' : 'hello from custom header'
      }),
    })
    .pipe(
      map(responseData => {
        const postArray: Post[] = [];
        for (const key in responseData) {
          if (responseData.hasOwnProperty(key)) {
            postArray.push({...responseData[key], id: key})
          }
        }
        return postArray;
      })
    );
  }

  //for deleting Data
  deletePosts() {
    return this.http.delete(this.postURL);
  }
}
