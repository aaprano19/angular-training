import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'
import { Post } from './post.model';
import { NgForm } from '@angular/forms';
import { title } from 'process';
import { Content } from '@angular/compiler/src/render3/r3_ast';
import { PostService } from './post.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  endPointURL:string = 'https://angular-exercise-6d5a3-default-rtdb.asia-southeast1.firebasedatabase.app/'
  postURL: string = this.endPointURL+'post.json';
  loadedPosts = [];
  showLoading = false;
  error = null;

  @ViewChild('putForm') viewchildputform : NgForm;

  // constructor(private http: HttpClient) {}
  constructor(private postService: PostService) {}

  ngOnInit() {}

  onCreatePost(postData: { title: string; content: string }) {
    // Send Http request
    console.log(postData);
    // this.http.post(this.postURL, postData).subscribe(
    // this.http.post<{name: string}>(this.postURL, postData).subscribe(
    //   (data) => {
    //     console.log(data);
    //   }
    // )
    this.postService.createAndPost(postData);
  }

  onUpdatePost(putData: { id: string, title: string; content: string }) {
    // Send Http request
    // console.log(putData);
    // this.http.put<{name: string}>(this.postURL, putData).subscribe(
    //   (data) => {
    //     console.log(data);
    //   }
    // )
    console.log(putData);
    // const updateData = {
    //   [putData.id]: {title: putData.title, content: putData.content}
    // };
    // this.http.patch(this.postURL, updateData).subscribe((data) => {
    //   console.log(data);
    // });
    this.postService.updateAndPost(putData);
  }

  onFetchPosts() {
    // Send Http request
    this.fetchPosts();
  }

  onClearPosts() {
    // Send Http request
    this.showLoading = true;
    this.postService.deletePosts().subscribe (
      (data) => {
        this.showLoading = false;
        this.loadedPosts = [];
      }
    )
  }

  onClicked(post:Post) {
    this.viewchildputform.setValue({id: post.id, title: post.title, content: post.content});
    // this.viewchildputform.setValue({title: post.title, content: post.content});
  }

  private fetchPosts(){
    // this.http.get(this.postURL)
    this.showLoading = true;
    // this.http.get<{[key: string] : Post}>(this.postURL)
    // .pipe(
    //   map( responseData => {
    //     const postArray:Post[] = [];
    //     for(const key in responseData) {
    //       if(responseData.hasOwnProperty(key)) {
    //         postArray.push({...responseData[key], id: key})
    //       }
    //     }
    //     return postArray;
    //   })
    // )
    // .subscribe (
    //   posts => {
    //     // console.log(posts);
    //     this.showLoading = false;
    //     this.loadedPosts = posts;
    //   }
    // );
    this.postService.fetchPosts()
    .subscribe(
      posts => {
        this.showLoading = false;
        this.loadedPosts = posts;
      },
      error => {
        console.log(error);
        this.error = error;
      }
    );
  }
}
